import pandas as pd


try:
    df_rfm = pd.read_csv("rfm_table.csv")
    df_pred_compra = pd.read_csv("next_purchase_predictions.csv")
    df_pred_trecho = pd.read_csv("trecho_predictions.csv")


    df_pred_compra['purchase_ts'] = pd.to_datetime(df_pred_compra['purchase_ts'])
    ultima_pred_compra = df_pred_compra.loc[df_pred_compra.groupby('customer_id')['purchase_ts'].idxmax()]

    df_pred_trecho['purchase_ts'] = pd.to_datetime(df_pred_trecho['purchase_ts'])
    ultima_pred_trecho = df_pred_trecho.loc[df_pred_trecho.groupby('customer_id')['purchase_ts'].idxmax()]


    df_final = df_rfm
    df_final = pd.merge(df_final, ultima_pred_compra[['customer_id', 'prob']], on='customer_id', how='left')
    df_final = pd.merge(df_final, ultima_pred_trecho[['customer_id', 'pred_route']], on='customer_id', how='left')
    df_final.rename(columns={'prob': 'prob_prox_compra_30d', 'pred_route': 'trecho_recomendado'}, inplace=True)
    df_final.to_csv("dashboard_final_data.csv", index=False, sep=';')

    print("\nArquivo final 'dashboard_final_data.csv' criado com sucesso!")
    print("\nVisualização das 5 primeiras linhas do arquivo final:")
    print(df_final.head())

except FileNotFoundError as e:
    print(f"\nERRO: Arquivo não encontrado! -> {e}")
    print("Por favor, certifique-se de que os arquivos 'rfm_table.csv', 'next_purchase_predictions.csv', e 'trecho_predictions.csv' estão na mesma pasta.")