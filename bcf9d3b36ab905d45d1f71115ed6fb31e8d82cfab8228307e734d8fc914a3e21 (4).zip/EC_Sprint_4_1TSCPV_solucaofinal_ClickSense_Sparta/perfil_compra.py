import pandas as pd
from datetime import datetime
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import seaborn as sns

CSV_IN = "clickbus_clean.csv"
df = pd.read_csv(CSV_IN, sep=';')
df['purchase_ts'] = pd.to_datetime(df['purchase_ts'])

snapshot_date = df['purchase_ts'].max() + pd.Timedelta(days=1)
rfm = df.groupby('customer_id').agg({
    'purchase_ts': lambda x: (snapshot_date - x.max()).days,
    'order_id': 'count',
    'gmv_success': 'mean'
}).rename(columns={
    'purchase_ts': 'recency',
    'order_id': 'frequency',
    'gmv_success': 'monetary'
}).reset_index()

rfm_norm = (rfm[["recency", "frequency", "monetary"]] - rfm[["recency", "frequency", "monetary"]].min()) / (rfm[["recency", "frequency", "monetary"]].max() - rfm[["recency", "frequency", "monetary"]].min())
kmeans = KMeans(n_clusters=3, random_state=42, n_init=10).fit(rfm_norm.fillna(0))
rfm["cluster"] = kmeans.labels_


rfm_avg = rfm.groupby('cluster')[['recency', 'frequency', 'monetary']].mean().reset_index()


cluster_fiel = rfm_avg.sort_values('recency', ascending=True).iloc[0]['cluster']
cluster_risco = rfm_avg.sort_values('recency', ascending=False).iloc[0]['cluster']
cluster_ocasional = rfm_avg[~rfm_avg['cluster'].isin([cluster_fiel, cluster_risco])]['cluster'].values[0]


mapa_personas = {
    cluster_fiel: 'Cliente Fiel',
    cluster_risco: 'Cliente em Risco',
    cluster_ocasional: 'Cliente Ocasional'
}

rfm['persona'] = rfm['cluster'].map(mapa_personas)

rfm.to_csv("rfm_table.csv", index=False)
print("Gerado: rfm_table.csv (com a coluna de personas)")


fig, axes = plt.subplots(1, 3, figsize=(20, 7))
fig.suptitle('Comparação das Métricas RFM por Persona', fontsize=18, weight='bold')

sns.barplot(ax=axes[0], data=rfm, x='persona', y='recency', palette='viridis', hue='persona', legend=False, order=['Cliente Fiel', 'Cliente Ocasional', 'Cliente em Risco'])
axes[0].set_title('Recência Média')
sns.barplot(ax=axes[1], data=rfm, x='persona', y='frequency', palette='viridis', hue='persona', legend=False, order=['Cliente Fiel', 'Cliente Ocasional', 'Cliente em Risco'])
axes[1].set_title('Frequência Média')
sns.barplot(ax=axes[2], data=rfm, x='persona', y='monetary', palette='viridis', hue='persona', legend=False, order=['Cliente Fiel', 'Cliente Ocasional', 'Cliente em Risco'])
axes[2].set_title('Valor Monetário Médio')

plt.tight_layout(rect=[0, 0, 1, 0.95])
plt.savefig("cluster_barcharts_personas.png", dpi=300)
print("Gerado: cluster_barcharts_personas.png")